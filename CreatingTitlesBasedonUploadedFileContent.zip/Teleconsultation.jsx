import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useUser } from '../contexts/UserContext'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Phone, 
  MessageCircle, 
  Send,
  Monitor,
  FileText,
  Clock,
  Heart,
  Minimize2,
  Maximize2
} from 'lucide-react'
import { toast } from 'sonner'

const Teleconsultation = () => {
  const navigate = useNavigate()
  const { user } = useUser()
  const [isVideoOn, setIsVideoOn] = useState(true)
  const [isAudioOn, setIsAudioOn] = useState(true)
  const [chatMessage, setChatMessage] = useState('')
  const [chatMessages, setChatMessages] = useState([])
  const [consultationTime, setConsultationTime] = useState(0)
  const [isMinimized, setIsMinimized] = useState(false)

  // Dados mockados do médico
  const doctor = {
    name: 'Dr. Carlos Oliveira',
    specialty: 'Cardiologia',
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face',
    crm: 'CRM/SP 123456'
  }

  // Timer da consulta
  useEffect(() => {
    const timer = setInterval(() => {
      setConsultationTime(prev => prev + 1)
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  // Mensagens automáticas do médico
  useEffect(() => {
    const initialMessages = [
      {
        id: 1,
        sender: 'doctor',
        message: 'Olá! Bem-vindo à teleconsulta. Como você está se sentindo hoje?',
        timestamp: new Date()
      }
    ]
    setChatMessages(initialMessages)

    // Simular mensagens do médico
    const timeouts = [
      setTimeout(() => {
        setChatMessages(prev => [...prev, {
          id: Date.now(),
          sender: 'doctor',
          message: 'Vou revisar seu histórico médico rapidamente.',
          timestamp: new Date()
        }])
      }, 5000),
      
      setTimeout(() => {
        setChatMessages(prev => [...prev, {
          id: Date.now(),
          sender: 'doctor',
          message: 'Pode me contar sobre os sintomas que você tem sentido?',
          timestamp: new Date()
        }])
      }, 10000)
    ]

    return () => timeouts.forEach(clearTimeout)
  }, [])

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const handleSendMessage = () => {
    if (chatMessage.trim()) {
      const newMessage = {
        id: Date.now(),
        sender: 'patient',
        message: chatMessage,
        timestamp: new Date()
      }
      setChatMessages(prev => [...prev, newMessage])
      setChatMessage('')

      // Simular resposta do médico
      setTimeout(() => {
        setChatMessages(prev => [...prev, {
          id: Date.now() + 1,
          sender: 'doctor',
          message: 'Entendi. Vou anotar essas informações.',
          timestamp: new Date()
        }])
      }, 2000)
    }
  }

  const handleEndCall = () => {
    toast.success('Consulta finalizada com sucesso!')
    navigate('/home')
  }

  const toggleVideo = () => {
    setIsVideoOn(!isVideoOn)
    toast.info(isVideoOn ? 'Câmera desligada' : 'Câmera ligada')
  }

  const toggleAudio = () => {
    setIsAudioOn(!isAudioOn)
    toast.info(isAudioOn ? 'Microfone desligado' : 'Microfone ligado')
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Heart className="h-6 w-6 text-blue-400 mr-2" />
              <span className="text-xl font-bold text-white">OSZO Teleconsulta</span>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="secondary" className="bg-green-600 text-white">
                <Clock className="h-3 w-3 mr-1" />
                {formatTime(consultationTime)}
              </Badge>
              <Badge variant="outline" className="text-white border-gray-600">
                Em andamento
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-80px)]">
        {/* Video Area */}
        <div className="flex-1 relative">
          {/* Doctor Video */}
          <div className="h-full bg-gray-800 relative">
            {/* Simulated doctor video */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-gray-900 flex items-center justify-center">
              <div className="text-center">
                <Avatar className="h-32 w-32 mx-auto mb-4">
                  <AvatarImage src={doctor.image} alt={doctor.name} />
                  <AvatarFallback className="text-2xl">{doctor.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <h2 className="text-2xl font-bold text-white mb-2">{doctor.name}</h2>
                <p className="text-gray-300">{doctor.specialty}</p>
                <p className="text-sm text-gray-400">{doctor.crm}</p>
              </div>
            </div>

            {/* Doctor info overlay */}
            <div className="absolute top-4 left-4">
              <Card className="bg-black/50 border-gray-600">
                <CardContent className="p-3">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span className="text-white text-sm">Dr. Carlos conectado</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Patient video (small) */}
            <div className="absolute bottom-4 right-4 w-48 h-36 bg-gray-700 rounded-lg border-2 border-gray-600 overflow-hidden">
              {isVideoOn ? (
                <div className="h-full bg-gradient-to-br from-green-900 to-gray-900 flex items-center justify-center">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={user?.avatar} alt={user?.name} />
                    <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
                  </Avatar>
                </div>
              ) : (
                <div className="h-full bg-gray-800 flex items-center justify-center">
                  <VideoOff className="h-8 w-8 text-gray-400" />
                </div>
              )}
              <div className="absolute bottom-2 left-2">
                <span className="text-white text-xs bg-black/50 px-2 py-1 rounded">
                  Você {!isAudioOn && '(mudo)'}
                </span>
              </div>
              <Button
                size="sm"
                variant="ghost"
                className="absolute top-2 right-2 h-6 w-6 p-0"
                onClick={() => setIsMinimized(!isMinimized)}
              >
                {isMinimized ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
              </Button>
            </div>
          </div>

          {/* Controls */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
            <div className="flex items-center space-x-4 bg-black/70 rounded-full px-6 py-3">
              <Button
                size="sm"
                variant={isAudioOn ? "secondary" : "destructive"}
                className="rounded-full h-12 w-12"
                onClick={toggleAudio}
              >
                {isAudioOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
              </Button>
              
              <Button
                size="sm"
                variant={isVideoOn ? "secondary" : "destructive"}
                className="rounded-full h-12 w-12"
                onClick={toggleVideo}
              >
                {isVideoOn ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
              </Button>
              
              <Button
                size="sm"
                variant="secondary"
                className="rounded-full h-12 w-12"
              >
                <Monitor className="h-5 w-5" />
              </Button>
              
              <Button
                size="sm"
                variant="secondary"
                className="rounded-full h-12 w-12"
              >
                <FileText className="h-5 w-5" />
              </Button>
              
              <Button
                size="sm"
                variant="destructive"
                className="rounded-full h-12 w-12"
                onClick={handleEndCall}
              >
                <Phone className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Chat Sidebar */}
        <div className="w-80 bg-white border-l border-gray-200 flex flex-col">
          <div className="p-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold flex items-center">
              <MessageCircle className="h-5 w-5 mr-2" />
              Chat da Consulta
            </h3>
          </div>

          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {chatMessages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === 'patient' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-xs px-3 py-2 rounded-lg ${
                      message.sender === 'patient'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    <p className="text-sm">{message.message}</p>
                    <p className="text-xs opacity-70 mt-1">
                      {message.timestamp.toLocaleTimeString('pt-BR', {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="p-4 border-t border-gray-200">
            <div className="flex space-x-2">
              <Input
                placeholder="Digite sua mensagem..."
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              />
              <Button size="sm" onClick={handleSendMessage}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Teleconsultation

