from flask import Blueprint, jsonify, request
from src.models.notificacao import Notificacao, db
from datetime import datetime

notificacao_bp = Blueprint('notificacao', __name__)

@notificacao_bp.route('/notificacoes', methods=['GET'])
def get_notificacoes():
    usuario_id = request.args.get('usuario_id')
    read = request.args.get('read')
    
    query = Notificacao.query
    if usuario_id:
        query = query.filter_by(usuario_id=usuario_id)
    if read is not None:
        read_bool = read.lower() == 'true'
        query = query.filter_by(read=read_bool)
    
    notificacoes = query.order_by(Notificacao.created_at.desc()).all()
    return jsonify([notif.to_dict() for notif in notificacoes])

@notificacao_bp.route('/notificacoes', methods=['POST'])
def create_notificacao():
    data = request.json
    
    data_agendamento = None
    if data.get('data_agendamento'):
        data_agendamento = datetime.fromisoformat(data['data_agendamento'])
    
    notificacao = Notificacao(
        usuario_id=data['usuario_id'],
        type=data['type'],
        title=data['title'],
        message=data['message'],
        read=data.get('read', False),
        data_agendamento=data_agendamento
    )
    
    db.session.add(notificacao)
    db.session.commit()
    return jsonify(notificacao.to_dict()), 201

@notificacao_bp.route('/notificacoes/<int:notificacao_id>', methods=['GET'])
def get_notificacao(notificacao_id):
    notificacao = Notificacao.query.get_or_404(notificacao_id)
    return jsonify(notificacao.to_dict())

@notificacao_bp.route('/notificacoes/<int:notificacao_id>', methods=['PUT'])
def update_notificacao(notificacao_id):
    notificacao = Notificacao.query.get_or_404(notificacao_id)
    data = request.json
    
    notificacao.read = data.get('read', notificacao.read)
    notificacao.title = data.get('title', notificacao.title)
    notificacao.message = data.get('message', notificacao.message)
    
    db.session.commit()
    return jsonify(notificacao.to_dict())

@notificacao_bp.route('/notificacoes/<int:notificacao_id>/marcar-lida', methods=['PUT'])
def marcar_como_lida(notificacao_id):
    notificacao = Notificacao.query.get_or_404(notificacao_id)
    notificacao.read = True
    db.session.commit()
    return jsonify(notificacao.to_dict())

@notificacao_bp.route('/notificacoes/<int:notificacao_id>', methods=['DELETE'])
def delete_notificacao(notificacao_id):
    notificacao = Notificacao.query.get_or_404(notificacao_id)
    db.session.delete(notificacao)
    db.session.commit()
    return '', 204

