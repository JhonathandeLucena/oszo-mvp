#!/usr/bin/env python3
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.main import app
from src.models.user import db, User
from src.models.medico import Medico, HorarioDisponivel
from src.models.consulta import Consulta
from src.models.documento_medico import DocumentoMedico
from src.models.notificacao import Notificacao
from datetime import datetime, date, time

def populate_database():
    with app.app_context():
        # Limpar dados existentes
        db.drop_all()
        db.create_all()
        
        # Criar usuários de teste
        users = [
            User(
                name='João Silva',
                email='joao@email.com',
                password='2o02!aKPmS{N',
                cpf='123.456.789-00'
            ),
            User(
                name='Maria Santos',
                email='maria@email.com',
                password='2o02!aKPmS{N',
                cpf='987.654.321-00'
            )
        ]
        
        for user in users:
            db.session.add(user)
        
        # Criar médicos de teste
        medicos = [
            Medico(
                name='Dr. Carlos Oliveira',
                specialty='Cardiologia',
                rating=4.8,
                price=250.00,
                image='https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face',
                crm='CRM/SP 123456'
            ),
            Medico(
                name='Dra. Ana Costa',
                specialty='Dermatologia',
                rating=4.9,
                price=200.00,
                image='https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&h=150&fit=crop&crop=face',
                crm='CRM/SP 789012'
            ),
            Medico(
                name='Dr. Pedro Mendes',
                specialty='Neurologia',
                rating=4.7,
                price=300.00,
                image='https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&h=150&fit=crop&crop=face',
                crm='CRM/SP 345678'
            ),
            Medico(
                name='Dra. Lucia Fernandes',
                specialty='Ginecologia',
                rating=4.6,
                price=220.00,
                image='https://images.unsplash.com/photo-1594824475317-d0b1e7e5b9e8?w=150&h=150&fit=crop&crop=face',
                crm='CRM/SP 456789'
            )
        ]
        
        for medico in medicos:
            db.session.add(medico)
        
        db.session.commit()
        
        # Criar consultas de teste
        consultas = [
            Consulta(
                type='online',
                specialty='Cardiologia',
                medico_id=1,
                paciente_id=1,
                data=date(2024, 9, 15),
                hora=time(10, 0),
                status='agendada'
            ),
            Consulta(
                type='presencial',
                specialty='Dermatologia',
                medico_id=2,
                paciente_id=1,
                data=date(2024, 9, 20),
                hora=time(15, 0),
                status='confirmada'
            )
        ]
        
        for consulta in consultas:
            db.session.add(consulta)
        
        # Criar documentos médicos de teste
        documentos = [
            DocumentoMedico(
                title='Exame de Sangue - Hemograma Completo',
                type='exame',
                paciente_id=1,
                medico_nome='Dr. Carlos Oliveira',
                descricao='Exame de rotina para check-up geral',
                data_documento=date(2024, 8, 25)
            ),
            DocumentoMedico(
                title='Receita Médica - Medicamentos para Pressão',
                type='receita',
                paciente_id=1,
                medico_nome='Dr. Carlos Oliveira',
                descricao='Prescrição de medicamentos para controle da pressão arterial',
                data_documento=date(2024, 8, 30)
            ),
            DocumentoMedico(
                title='Relatório de Consulta Cardiológica',
                type='relatório',
                paciente_id=1,
                medico_nome='Dr. Carlos Oliveira',
                descricao='Relatório detalhado da consulta cardiológica',
                data_documento=date(2024, 9, 5)
            )
        ]
        
        for documento in documentos:
            db.session.add(documento)
        
        # Criar notificações de teste
        notificacoes = [
            Notificacao(
                usuario_id=1,
                type='consulta',
                title='Consulta Agendada',
                message='Sua consulta com Dr. Carlos Oliveira está agendada para amanhã às 10:00',
                read=False
            ),
            Notificacao(
                usuario_id=1,
                type='exame',
                title='Resultado de Exame',
                message='O resultado do seu exame de sangue já está disponível no seu histórico médico',
                read=False
            ),
            Notificacao(
                usuario_id=1,
                type='medicamento',
                title='Lembrete de Medicamento',
                message='Não esqueça de tomar seu medicamento para pressão às 20:00',
                read=True
            )
        ]
        
        for notificacao in notificacoes:
            db.session.add(notificacao)
        
        db.session.commit()
        print("Banco de dados populado com sucesso!")

if __name__ == '__main__':
    populate_database()

