from .user import User, db
from .medico import Medico, HorarioDisponivel
from .consulta import Consulta
from .documento_medico import DocumentoMedico
from .notificacao import Notificacao

__all__ = ['User', 'Medico', 'HorarioDisponivel', 'Consulta', 'DocumentoMedico', 'Notificacao', 'db']

