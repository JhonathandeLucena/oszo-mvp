import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.main import app
from src.models.user import User, db
from werkzeug.security import generate_password_hash

def create_admin_user():
    with app.app_context():
        # Verificar se já existe um administrador
        admin_user = User.query.filter_by(user_type='administrador').first()
        
        if admin_user:
            print("Usuário administrador já existe!")
            print(f"Email: {admin_user.email}")
            return
        
        # Criar usuário administrador
        admin_password = generate_password_hash('admin123')
        
        admin = User(
            name='Administrador OSZO',
            email='admin@oszo.com',
            cpf='000.000.000-00',
            password=admin_password,
            user_type='administrador'
        )
        
        db.session.add(admin)
        db.session.commit()
        
        print("Usuário administrador criado com sucesso!")
        print("Email: admin@oszo.com")
        print("Senha: admin123")

if __name__ == '__main__':
    create_admin_user()

