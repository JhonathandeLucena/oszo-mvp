import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  UserCheck, 
  Calendar, 
  FileText, 
  Bell, 
  Settings,
  Plus,
  TrendingUp,
  Activity,
  Clock
} from 'lucide-react';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({});
  const [activities, setActivities] = useState([]);
  const [activeTab, setActiveTab] = useState('Visão Geral');

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      // Buscar estatísticas
      const statsResponse = await fetch('http://localhost:5000/api/admin/dashboard');
      const statsData = await statsResponse.json();
      setStats(statsData);

      // Buscar atividades recentes
      const activitiesResponse = await fetch('http://localhost:5000/api/admin/recent-activities');
      const activitiesData = await activitiesResponse.json();
      setActivities(activitiesData);
    } catch (error) {
      console.error('Erro ao buscar dados do dashboard:', error);
    }
  };

  const tabs = ['Visão Geral', 'Pacientes', 'Profissionais', 'Relatórios'];

  const getActivityIcon = (type) => {
    switch (type) {
      case 'consulta':
        return <Calendar className="w-4 h-4 text-blue-500" />;
      case 'paciente':
        return <Users className="w-4 h-4 text-green-500" />;
      case 'laudo':
        return <FileText className="w-4 h-4 text-purple-500" />;
      default:
        return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  const getActivityColor = (status) => {
    switch (status) {
      case 'recent':
        return 'bg-blue-50 border-blue-200';
      case 'success':
        return 'bg-green-50 border-green-200';
      case 'completed':
        return 'bg-purple-50 border-purple-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                  <Settings className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-gray-900">OSZO Admin</h1>
                  <p className="text-sm text-gray-500">Painel Administrativo</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button className="relative p-2 text-gray-400 hover:text-gray-500">
                <Bell className="w-6 h-6" />
                <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-400 ring-2 ring-white"></span>
              </button>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-700">Notificações</span>
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm font-medium">DI</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'Visão Geral' && (
          <div className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Users className="h-8 w-8 text-blue-500" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Total de Pacientes
                      </dt>
                      <dd className="text-lg font-medium text-gray-900">
                        {stats.total_pacientes?.value || 4}
                      </dd>
                      <dd className="text-sm text-gray-500">
                        {stats.total_pacientes?.variation || '+12% vs mês anterior'}
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <UserCheck className="h-8 w-8 text-green-500" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Profissionais Ativos
                      </dt>
                      <dd className="text-lg font-medium text-gray-900">
                        {stats.profissionais_ativos?.value || 4}
                      </dd>
                      <dd className="text-sm text-gray-500">
                        {stats.profissionais_ativos?.variation || '+3% vs mês anterior'}
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Calendar className="h-8 w-8 text-blue-500" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Consultas Agendadas
                      </dt>
                      <dd className="text-lg font-medium text-gray-900">
                        {stats.consultas_agendadas?.value || 2}
                      </dd>
                      <dd className="text-sm text-gray-500">
                        {stats.consultas_agendadas?.variation || '+25% vs mês anterior'}
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <FileText className="h-8 w-8 text-green-500" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Laudos Gerados
                      </dt>
                      <dd className="text-lg font-medium text-gray-900">
                        {stats.laudos_gerados?.value || 2}
                      </dd>
                      <dd className="text-sm text-gray-500">
                        {stats.laudos_gerados?.variation || '+8% vs mês anterior'}
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions Grid */}
            <div>
              <h2 className="text-lg font-medium text-gray-900 mb-4">Ações Rápidas</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                      <Users className="w-6 h-6 text-blue-600" />
                    </div>
                    <h3 className="text-sm font-medium text-gray-900 mb-2">Gerenciar Pacientes</h3>
                    <p className="text-xs text-gray-500 mb-4">Cadastrar, editar e visualizar pacientes</p>
                    <button className="text-blue-600 text-sm font-medium hover:text-blue-700">
                      Acessar →
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                      <UserCheck className="w-6 h-6 text-green-600" />
                    </div>
                    <h3 className="text-sm font-medium text-gray-900 mb-2">Gerenciar Profissionais</h3>
                    <p className="text-xs text-gray-500 mb-4">Cadastrar, editar e visualizar profissionais</p>
                    <button className="text-green-600 text-sm font-medium hover:text-green-700">
                      Acessar →
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                      <Calendar className="w-6 h-6 text-blue-600" />
                    </div>
                    <h3 className="text-sm font-medium text-gray-900 mb-2">Consultas</h3>
                    <p className="text-xs text-gray-500 mb-4">Visualizar e gerenciar consultas</p>
                    <button className="text-blue-600 text-sm font-medium hover:text-blue-700">
                      Acessar →
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                      <FileText className="w-6 h-6 text-green-600" />
                    </div>
                    <h3 className="text-sm font-medium text-gray-900 mb-2">Relatórios</h3>
                    <p className="text-xs text-gray-500 mb-4">Laudos e documentos médicos</p>
                    <button className="text-green-600 text-sm font-medium hover:text-green-700">
                      Acessar →
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Activities */}
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-medium text-gray-900">Atividade Recente</h2>
                <p className="text-sm text-gray-500">Últimas ações no sistema</p>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {activities.map((activity) => (
                    <div
                      key={activity.id}
                      className={`flex items-center justify-between p-4 rounded-lg border ${getActivityColor(activity.status)}`}
                    >
                      <div className="flex items-center space-x-3">
                        {getActivityIcon(activity.type)}
                        <div>
                          <p className="text-sm font-medium text-gray-900">{activity.title}</p>
                          <p className="text-sm text-gray-500">{activity.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          {activity.time}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Placeholder para outras abas */}
        {activeTab !== 'Visão Geral' && (
          <div className="bg-white rounded-lg shadow p-8 text-center">
            <h2 className="text-xl font-medium text-gray-900 mb-2">{activeTab}</h2>
            <p className="text-gray-500">Esta seção está em desenvolvimento.</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;

