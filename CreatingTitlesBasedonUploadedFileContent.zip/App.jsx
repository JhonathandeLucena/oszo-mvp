import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import './App.css'

// Páginas
import Login from './pages/Login'
import Home from './pages/Home'
import AdminDashboard from './pages/AdminDashboard'
import Scheduling from './pages/Scheduling'
import Confirmation from './pages/Confirmation'
import Teleconsultation from './pages/Teleconsultation'
import MedicalHistory from './pages/MedicalHistory'
import Notifications from './pages/Notifications'
import Support from './pages/Support'

// Context para gerenciar estado global
import { UserProvider } from './contexts/UserContext'

function App() {
  return (
    <UserProvider>
      <Router>
        <div className="min-h-screen bg-background">
          <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/login" element={<Navigate to="/" replace />} />
            <Route path="/home" element={<Home />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/scheduling" element={<Scheduling />} />
            <Route path="/confirmation" element={<Confirmation />} />
            <Route path="/teleconsultation" element={<Teleconsultation />} />
            <Route path="/medical-history" element={<MedicalHistory />} />
            <Route path="/notifications" element={<Notifications />} />
            <Route path="/support" element={<Support />} />
          </Routes>
        </div>
      </Router>
    </UserProvider>
  )
}

export default App

