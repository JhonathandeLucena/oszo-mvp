import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useUser } from '../contexts/UserContext'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Calendar } from '@/components/ui/calendar'
import { 
  ArrowLeft, 
  Video, 
  MapPin, 
  Star, 
  Clock,
  Heart,
  User,
  LogOut
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'

const Scheduling = () => {
  const navigate = useNavigate()
  const { user, logout } = useUser()
  const [currentStep, setCurrentStep] = useState(1)
  const [selectedType, setSelectedType] = useState('')
  const [selectedSpecialty, setSelectedSpecialty] = useState('')
  const [selectedDoctor, setSelectedDoctor] = useState(null)
  const [selectedDate, setSelectedDate] = useState(null)
  const [selectedTime, setSelectedTime] = useState('')

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  const especialidades = [
    'Cardiologia', 'Dermatologia', 'Ginecologia', 
    'Neurologia', 'Ortopedia', 'Pediatria', 
    'Psiquiatria', 'Oftalmologia'
  ]

  const medicos = [
    {
      id: 1,
      name: 'Dr. Carlos Oliveira',
      specialty: 'Cardiologia',
      rating: 4.8,
      price: 250.00,
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face',
      crm: 'CRM/SP 123456'
    },
    {
      id: 2,
      name: 'Dra. Ana Costa',
      specialty: 'Dermatologia',
      rating: 4.9,
      price: 200.00,
      image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&h=150&fit=crop&crop=face',
      crm: 'CRM/SP 789012'
    },
    {
      id: 3,
      name: 'Dr. Pedro Mendes',
      specialty: 'Neurologia',
      rating: 4.7,
      price: 300.00,
      image: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&h=150&fit=crop&crop=face',
      crm: 'CRM/SP 345678'
    }
  ]

  const horarios = [
    '08:00', '09:00', '10:00', '11:00',
    '14:00', '15:00', '16:00', '17:00'
  ]

  const filteredDoctors = medicos.filter(medico => 
    selectedSpecialty === '' || medico.specialty === selectedSpecialty
  )

  const handleNext = () => {
    if (currentStep === 1 && !selectedType) {
      toast.error('Selecione o tipo de consulta')
      return
    }
    if (currentStep === 2 && !selectedSpecialty) {
      toast.error('Selecione uma especialidade')
      return
    }
    if (currentStep === 3 && !selectedDoctor) {
      toast.error('Selecione um médico')
      return
    }
    if (currentStep === 4 && !selectedDate) {
      toast.error('Selecione uma data')
      return
    }
    if (currentStep === 5 && !selectedTime) {
      toast.error('Selecione um horário')
      return
    }

    if (currentStep < 5) {
      setCurrentStep(currentStep + 1)
    } else {
      // Finalizar agendamento
      const consultaData = {
        type: selectedType,
        specialty: selectedSpecialty,
        doctor: selectedDoctor,
        date: selectedDate,
        time: selectedTime
      }
      
      // Salvar no localStorage para a página de confirmação
      localStorage.setItem('consultaAgendamento', JSON.stringify(consultaData))
      navigate('/confirmation')
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    } else {
      navigate('/home')
    }
  }

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Tipo de Consulta</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card 
                className={`cursor-pointer transition-all ${selectedType === 'online' ? 'ring-2 ring-blue-500 bg-blue-50' : 'hover:shadow-lg'}`}
                onClick={() => setSelectedType('online')}
              >
                <CardContent className="p-6 text-center">
                  <Video className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Teleconsulta</h3>
                  <p className="text-gray-600">Consulta online por videochamada</p>
                  <Badge className="mt-3">Mais rápido</Badge>
                </CardContent>
              </Card>
              
              <Card 
                className={`cursor-pointer transition-all ${selectedType === 'presencial' ? 'ring-2 ring-blue-500 bg-blue-50' : 'hover:shadow-lg'}`}
                onClick={() => setSelectedType('presencial')}
              >
                <CardContent className="p-6 text-center">
                  <MapPin className="h-12 w-12 text-green-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Presencial</h3>
                  <p className="text-gray-600">Consulta no consultório médico</p>
                  <Badge variant="secondary" className="mt-3">Tradicional</Badge>
                </CardContent>
              </Card>
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Especialidade</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {especialidades.map((especialidade) => (
                <Button
                  key={especialidade}
                  variant={selectedSpecialty === especialidade ? "default" : "outline"}
                  className="h-auto p-4 text-center"
                  onClick={() => setSelectedSpecialty(especialidade)}
                >
                  {especialidade}
                </Button>
              ))}
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Escolha o Médico</h2>
            <div className="space-y-4">
              {filteredDoctors.map((medico) => (
                <Card 
                  key={medico.id}
                  className={`cursor-pointer transition-all ${selectedDoctor?.id === medico.id ? 'ring-2 ring-blue-500 bg-blue-50' : 'hover:shadow-lg'}`}
                  onClick={() => setSelectedDoctor(medico)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={medico.image} alt={medico.name} />
                        <AvatarFallback>{medico.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold">{medico.name}</h3>
                        <p className="text-gray-600">{medico.specialty}</p>
                        <p className="text-sm text-gray-500">{medico.crm}</p>
                        <div className="flex items-center mt-2">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="ml-1 text-sm text-gray-600">{medico.rating}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-blue-600">
                          R$ {medico.price.toFixed(2)}
                        </p>
                        <p className="text-sm text-gray-500">por consulta</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Escolha a Data</h2>
            <div className="flex justify-center">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                disabled={(date) => date < new Date() || date.getDay() === 0 || date.getDay() === 6}
                className="rounded-md border"
              />
            </div>
            {selectedDate && (
              <p className="text-center text-gray-600 mt-4">
                Data selecionada: {selectedDate.toLocaleDateString('pt-BR')}
              </p>
            )}
          </div>
        )

      case 5:
        return (
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Escolha o Horário</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {horarios.map((horario) => (
                <Button
                  key={horario}
                  variant={selectedTime === horario ? "default" : "outline"}
                  className="h-12"
                  onClick={() => setSelectedTime(horario)}
                >
                  <Clock className="h-4 w-4 mr-2" />
                  {horario}
                </Button>
              ))}
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-blue-600 mr-2" />
              <span className="text-2xl font-bold text-gray-900">OSZO</span>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar} alt={user?.name} />
                    <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user?.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user?.email}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>Perfil</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Sair</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-3xl font-bold text-gray-900">Agendar Consulta</h1>
            <span className="text-sm text-gray-500">Etapa {currentStep} de 5</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / 5) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Content */}
        <Card>
          <CardContent className="p-8">
            {renderStep()}
          </CardContent>
        </Card>

        {/* Navigation Buttons */}
        <div className="flex justify-between mt-8">
          <Button variant="outline" onClick={handleBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            {currentStep === 1 ? 'Voltar ao Início' : 'Anterior'}
          </Button>
          
          <Button onClick={handleNext}>
            {currentStep === 5 ? 'Finalizar Agendamento' : 'Próximo'}
          </Button>
        </div>
      </div>
    </div>
  )
}

export default Scheduling

