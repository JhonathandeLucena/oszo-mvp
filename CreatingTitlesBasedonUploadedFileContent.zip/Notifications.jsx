import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useUser } from '../contexts/UserContext'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Bell, 
  Calendar, 
  Activity, 
  Pill, 
  Check, 
  X,
  Clock,
  Heart,
  User,
  LogOut,
  ArrowLeft,
  Settings,
  MoreVertical
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'

const Notifications = () => {
  const navigate = useNavigate()
  const { user, logout } = useUser()
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'consulta',
      title: 'Consulta Agendada',
      message: 'Sua consulta com Dr. Carlos Oliveira está agendada para amanhã às 10:00',
      read: false,
      timestamp: new Date('2024-09-10T14:30:00'),
      priority: 'high'
    },
    {
      id: 2,
      type: 'exame',
      title: 'Resultado de Exame',
      message: 'O resultado do seu exame de sangue já está disponível no seu histórico médico',
      read: false,
      timestamp: new Date('2024-09-10T09:15:00'),
      priority: 'medium'
    },
    {
      id: 3,
      type: 'medicamento',
      title: 'Lembrete de Medicamento',
      message: 'Não esqueça de tomar seu medicamento para pressão às 20:00',
      read: true,
      timestamp: new Date('2024-09-09T19:45:00'),
      priority: 'low'
    },
    {
      id: 4,
      type: 'consulta',
      title: 'Confirmação de Consulta',
      message: 'Sua consulta de amanhã foi confirmada. Lembre-se de chegar 15 minutos antes.',
      read: true,
      timestamp: new Date('2024-09-09T16:20:00'),
      priority: 'medium'
    },
    {
      id: 5,
      type: 'exame',
      title: 'Agendamento de Exame',
      message: 'Seu exame de eletrocardiograma foi agendado para sexta-feira às 14:00',
      read: false,
      timestamp: new Date('2024-09-08T11:30:00'),
      priority: 'medium'
    },
    {
      id: 6,
      type: 'medicamento',
      title: 'Renovação de Receita',
      message: 'Sua receita médica vence em 3 dias. Agende uma consulta para renovação.',
      read: false,
      timestamp: new Date('2024-09-07T08:00:00'),
      priority: 'high'
    }
  ])

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  const getTypeIcon = (type) => {
    switch (type) {
      case 'consulta':
        return <Calendar className="h-4 w-4" />
      case 'exame':
        return <Activity className="h-4 w-4" />
      case 'medicamento':
        return <Pill className="h-4 w-4" />
      default:
        return <Bell className="h-4 w-4" />
    }
  }

  const getTypeColor = (type) => {
    switch (type) {
      case 'consulta':
        return 'bg-blue-100 text-blue-800'
      case 'exame':
        return 'bg-green-100 text-green-800'
      case 'medicamento':
        return 'bg-purple-100 text-purple-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800'
      case 'medium':
        return 'bg-yellow-100 text-yellow-800'
      case 'low':
        return 'bg-green-100 text-green-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const formatTimestamp = (timestamp) => {
    const now = new Date()
    const diff = now - timestamp
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)

    if (minutes < 60) {
      return `${minutes} min atrás`
    } else if (hours < 24) {
      return `${hours}h atrás`
    } else if (days < 7) {
      return `${days}d atrás`
    } else {
      return timestamp.toLocaleDateString('pt-BR')
    }
  }

  const markAsRead = (id) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === id ? { ...notif, read: true } : notif
      )
    )
    toast.success('Notificação marcada como lida')
  }

  const markAsUnread = (id) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === id ? { ...notif, read: false } : notif
      )
    )
    toast.success('Notificação marcada como não lida')
  }

  const deleteNotification = (id) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id))
    toast.success('Notificação removida')
  }

  const markAllAsRead = () => {
    setNotifications(prev =>
      prev.map(notif => ({ ...notif, read: true }))
    )
    toast.success('Todas as notificações foram marcadas como lidas')
  }

  const unreadCount = notifications.filter(n => !n.read).length
  const consultaNotifications = notifications.filter(n => n.type === 'consulta')
  const exameNotifications = notifications.filter(n => n.type === 'exame')
  const medicamentoNotifications = notifications.filter(n => n.type === 'medicamento')

  const NotificationCard = ({ notification }) => (
    <Card className={`transition-all hover:shadow-lg ${!notification.read ? 'border-l-4 border-l-blue-500 bg-blue-50/30' : ''}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-3 flex-1">
            <div className={`p-2 rounded-lg ${getTypeColor(notification.type)}`}>
              {getTypeIcon(notification.type)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2 mb-1">
                <h3 className={`font-semibold ${!notification.read ? 'text-gray-900' : 'text-gray-700'}`}>
                  {notification.title}
                </h3>
                {!notification.read && (
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                )}
              </div>
              <p className={`text-sm mb-2 ${!notification.read ? 'text-gray-700' : 'text-gray-600'}`}>
                {notification.message}
              </p>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className={getPriorityColor(notification.priority)}>
                  {notification.priority === 'high' ? 'Alta' : 
                   notification.priority === 'medium' ? 'Média' : 'Baixa'}
                </Badge>
                <span className="text-xs text-gray-500 flex items-center">
                  <Clock className="h-3 w-3 mr-1" />
                  {formatTimestamp(notification.timestamp)}
                </span>
              </div>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {notification.read ? (
                <DropdownMenuItem onClick={() => markAsUnread(notification.id)}>
                  <Bell className="mr-2 h-4 w-4" />
                  Marcar como não lida
                </DropdownMenuItem>
              ) : (
                <DropdownMenuItem onClick={() => markAsRead(notification.id)}>
                  <Check className="mr-2 h-4 w-4" />
                  Marcar como lida
                </DropdownMenuItem>
              )}
              <DropdownMenuItem 
                onClick={() => deleteNotification(notification.id)}
                className="text-red-600"
              >
                <X className="mr-2 h-4 w-4" />
                Remover
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/home')}
                className="mr-4"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
              <Heart className="h-8 w-8 text-blue-600 mr-2" />
              <span className="text-2xl font-bold text-gray-900">OSZO</span>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar} alt={user?.name} />
                    <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user?.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user?.email}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>Perfil</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Sair</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Notificações</h1>
            <p className="text-gray-600">
              {unreadCount > 0 ? `Você tem ${unreadCount} notificação${unreadCount > 1 ? 'ões' : ''} não lida${unreadCount > 1 ? 's' : ''}` : 'Todas as notificações foram lidas'}
            </p>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4 mr-2" />
              Configurações
            </Button>
            {unreadCount > 0 && (
              <Button size="sm" onClick={markAllAsRead}>
                <Check className="h-4 w-4 mr-2" />
                Marcar todas como lidas
              </Button>
            )}
          </div>
        </div>

        {/* Notifications */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all">
              Todas ({notifications.length})
            </TabsTrigger>
            <TabsTrigger value="consulta">
              Consultas ({consultaNotifications.length})
            </TabsTrigger>
            <TabsTrigger value="exame">
              Exames ({exameNotifications.length})
            </TabsTrigger>
            <TabsTrigger value="medicamento">
              Medicamentos ({medicamentoNotifications.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            {notifications.length > 0 ? (
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <NotificationCard key={notification.id} notification={notification} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Nenhuma notificação
                  </h3>
                  <p className="text-gray-600">
                    Você não tem notificações no momento
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="consulta" className="mt-6">
            <div className="space-y-4">
              {consultaNotifications.map((notification) => (
                <NotificationCard key={notification.id} notification={notification} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="exame" className="mt-6">
            <div className="space-y-4">
              {exameNotifications.map((notification) => (
                <NotificationCard key={notification.id} notification={notification} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="medicamento" className="mt-6">
            <div className="space-y-4">
              {medicamentoNotifications.map((notification) => (
                <NotificationCard key={notification.id} notification={notification} />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default Notifications

