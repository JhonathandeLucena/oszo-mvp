import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from datetime import datetime, date, time, timedelta
from werkzeug.security import generate_password_hash
from flask import Flask
from flask_sqlalchemy import SQLAlchemy

# Criar app Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializar banco
db = SQLAlchemy(app)

# Importar todos os modelos
from src.models.user import User
from src.models.medico import Medico, HorarioDisponivel
from src.models.consulta import Consulta
from src.models.documento_medico import DocumentoMedico
from src.models.notificacao import Notificacao

def seed_database():
    with app.app_context():
        # Limpar dados existentes
        db.drop_all()
        db.create_all()
        
        # Criar usuários de teste
        usuarios = [
            {
                'name': 'João Silva',
                'email': 'joao@email.com',
                'cpf': '123.456.789-00',
                'avatar': 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
                'password': generate_password_hash('123456')
            },
            {
                'name': 'Maria Santos',
                'email': 'maria@email.com',
                'cpf': '987.654.321-00',
                'avatar': 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face',
                'password': generate_password_hash('123456')
            }
        ]
        
        for user_data in usuarios:
            user = User(**user_data)
            db.session.add(user)
        
        # Criar médicos
        medicos = [
            {
                'name': 'Dr. Carlos Oliveira',
                'specialty': 'Cardiologia',
                'rating': 4.8,
                'price': 250.00,
                'image': 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face',
                'crm': 'CRM/SP 123456'
            },
            {
                'name': 'Dra. Ana Costa',
                'specialty': 'Dermatologia',
                'rating': 4.9,
                'price': 200.00,
                'image': 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=150&h=150&fit=crop&crop=face',
                'crm': 'CRM/SP 789012'
            },
            {
                'name': 'Dr. Pedro Mendes',
                'specialty': 'Neurologia',
                'rating': 4.7,
                'price': 300.00,
                'image': 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&h=150&fit=crop&crop=face',
                'crm': 'CRM/SP 345678'
            },
            {
                'name': 'Dra. Lucia Ferreira',
                'specialty': 'Ginecologia',
                'rating': 4.9,
                'price': 220.00,
                'image': 'https://images.unsplash.com/photo-1594824475317-d3b7b4b6b7b7?w=150&h=150&fit=crop&crop=face',
                'crm': 'CRM/SP 901234'
            },
            {
                'name': 'Dr. Roberto Lima',
                'specialty': 'Ortopedia',
                'rating': 4.6,
                'price': 280.00,
                'image': 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=150&h=150&fit=crop&crop=face',
                'crm': 'CRM/SP 567890'
            }
        ]
        
        for medico_data in medicos:
            medico = Medico(**medico_data)
            db.session.add(medico)
        
        db.session.commit()
        
        # Criar horários disponíveis para os próximos 30 dias
        hoje = date.today()
        for i in range(30):
            data_consulta = hoje + timedelta(days=i)
            
            # Pular fins de semana
            if data_consulta.weekday() >= 5:
                continue
                
            for medico_id in range(1, 6):  # IDs dos médicos criados
                # Horários da manhã (8h às 12h)
                for hora in range(8, 12):
                    horario = HorarioDisponivel(
                        medico_id=medico_id,
                        data=data_consulta,
                        hora_inicio=time(hora, 0),
                        hora_fim=time(hora + 1, 0),
                        disponivel=True
                    )
                    db.session.add(horario)
                
                # Horários da tarde (14h às 18h)
                for hora in range(14, 18):
                    horario = HorarioDisponivel(
                        medico_id=medico_id,
                        data=data_consulta,
                        hora_inicio=time(hora, 0),
                        hora_fim=time(hora + 1, 0),
                        disponivel=True
                    )
                    db.session.add(horario)
        
        # Criar algumas consultas de exemplo
        consultas = [
            {
                'type': 'online',
                'specialty': 'Cardiologia',
                'medico_id': 1,
                'paciente_id': 1,
                'data': hoje + timedelta(days=3),
                'hora': time(10, 0),
                'status': 'agendada'
            },
            {
                'type': 'presencial',
                'specialty': 'Dermatologia',
                'medico_id': 2,
                'paciente_id': 1,
                'data': hoje + timedelta(days=7),
                'hora': time(15, 0),
                'status': 'confirmada'
            }
        ]
        
        for consulta_data in consultas:
            consulta = Consulta(**consulta_data)
            db.session.add(consulta)
        
        # Criar documentos médicos de exemplo
        documentos = [
            {
                'title': 'Exame de Sangue - Hemograma Completo',
                'type': 'exame',
                'paciente_id': 1,
                'medico_nome': 'Dr. Carlos Oliveira',
                'data_documento': hoje - timedelta(days=15),
                'descricao': 'Exame de rotina para check-up geral'
            },
            {
                'title': 'Receita Médica - Medicamentos para Pressão',
                'type': 'receita',
                'paciente_id': 1,
                'medico_nome': 'Dr. Carlos Oliveira',
                'data_documento': hoje - timedelta(days=10),
                'descricao': 'Prescrição de medicamentos para controle da pressão arterial'
            }
        ]
        
        for doc_data in documentos:
            documento = DocumentoMedico(**doc_data)
            db.session.add(documento)
        
        # Criar notificações de exemplo
        notificacoes = [
            {
                'usuario_id': 1,
                'type': 'consulta',
                'title': 'Consulta Agendada',
                'message': 'Sua consulta com Dr. Carlos Oliveira está agendada para amanhã às 10:00',
                'read': False
            },
            {
                'usuario_id': 1,
                'type': 'exame',
                'title': 'Resultado de Exame',
                'message': 'O resultado do seu exame de sangue já está disponível',
                'read': False
            },
            {
                'usuario_id': 1,
                'type': 'medicamento',
                'title': 'Lembrete de Medicamento',
                'message': 'Não esqueça de tomar seu medicamento às 20:00',
                'read': True
            }
        ]
        
        for notif_data in notificacoes:
            notificacao = Notificacao(**notif_data)
            db.session.add(notificacao)
        
        db.session.commit()
        print("Banco de dados populado com sucesso!")
        print("Usuários de teste:")
        print("- Email: joao@email.com, Senha: 123456")
        print("- Email: maria@email.com, Senha: 123456")

if __name__ == '__main__':
    seed_database()

