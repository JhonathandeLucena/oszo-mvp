import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useUser } from '../contexts/UserContext'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Heart, ArrowLeft, Eye, EyeOff, Shield, Users, Clock } from 'lucide-react'
import { toast } from 'sonner'

const Login = () => {
  const navigate = useNavigate()
  const { login } = useUser()
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [loginType, setLoginType] = useState('email') // 'email' ou 'sms'

  // Estados para login
  const [loginData, setLoginData] = useState({
    identifier: '',
    password: ''
  })

  // Estados para SMS
  const [smsData, setSmsData] = useState({
    phone: '',
    code: ''
  })

  // Estados para cadastro
  const [registerData, setRegisterData] = useState({
    name: '',
    email: '',
    cpf: '',
    password: '',
    confirmPassword: ''
  })

  const handleLogin = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Fazer requisição para a API de login
      const response = await fetch('http://localhost:5000/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          identifier: loginData.identifier,
          password: loginData.password
        })
      });

      const data = await response.json();

      if (data.success) {
        const userData = data.user;
        login(userData);
        toast.success('Login realizado com sucesso!');
        
        // Redirecionar baseado no tipo de usuário
        if (userData.user_type === 'administrador') {
          navigate('/admin');
        } else {
          navigate('/home');
        }
      } else {
        toast.error(data.message || 'Credenciais inválidas');
      }
    } catch (error) {
      console.error('Erro no login:', error);
      
      // Fallback para dados mockados se a API não estiver disponível
      if (loginData.identifier === 'joao@email.com' && loginData.password === '2o02!aKPmS{N') {
        const userData = {
          id: 1,
          name: 'João Silva',
          email: 'joao@email.com',
          cpf: '123.456.789-00',
          user_type: 'paciente',
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face'
        }
        login(userData)
        toast.success('Login realizado com sucesso!')
        navigate('/home')
      } else if (loginData.identifier === 'admin@oszo.com' && loginData.password === 'admin123') {
        const userData = {
          id: 2,
          name: 'Administrador OSZO',
          email: 'admin@oszo.com',
          cpf: '000.000.000-00',
          user_type: 'administrador',
          avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face'
        }
        login(userData)
        toast.success('Login realizado com sucesso!')
        navigate('/admin')
      } else {
        toast.error('Credenciais inválidas')
      }
    } finally {
      setLoading(false)
    }
  }

  const handleSMSLogin = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Simular envio de SMS
      toast.success('Código SMS enviado!')
      // Aqui você implementaria a lógica real de SMS
    } catch (error) {
      toast.error('Erro ao enviar SMS')
    } finally {
      setLoading(false)
    }
  }

  const handleRegister = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      if (registerData.password !== registerData.confirmPassword) {
        toast.error('As senhas não coincidem')
        return
      }

      // Simular cadastro
      const userData = {
        id: Date.now(),
        name: registerData.name,
        email: registerData.email,
        cpf: registerData.cpf,
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face'
      }
      
      login(userData)
      toast.success('Conta criada com sucesso!')
      navigate('/home')
    } catch (error) {
      toast.error('Erro ao criar conta')
    } finally {
      setLoading(false)
    }
  }

  const formatCPF = (value) => {
    const numbers = value.replace(/\D/g, '')
    return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4')
  }

  const formatPhone = (value) => {
    const numbers = value.replace(/\D/g, '')
    return numbers.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex">
      {/* Left Side - Illustration and Info */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-blue-400 to-cyan-400 p-12 flex-col justify-center items-center">
        <div className="max-w-md w-full">
          <div className="flex items-center justify-center mb-8">
            <Heart className="h-8 w-8 text-white mr-3" />
            <span className="text-2xl font-bold text-white">OSZO</span>
          </div>
          
          <h1 className="text-4xl font-bold text-white mb-6 text-center">
            Saúde Digital<br />
            <span className="text-blue-100">Acessível</span>
          </h1>
          
          <p className="text-blue-50 text-lg mb-8 leading-relaxed text-center">
            Conectamos você aos melhores profissionais de saúde da Zona Oeste do 
            Rio de Janeiro. Consultas presenciais e telemedicina em uma plataforma integrada.
          </p>

          <div className="space-y-6 mb-8">
            <div className="flex items-center text-white justify-center">
              <Shield className="h-6 w-6 mr-4 text-blue-100" />
              <div>
                <h3 className="font-semibold">Seguro</h3>
                <p className="text-blue-100 text-sm">Dados protegidos</p>
              </div>
            </div>
            
            <div className="flex items-center text-white justify-center">
              <Heart className="h-6 w-6 mr-4 text-blue-100" />
              <div>
                <h3 className="font-semibold">Cuidado</h3>
                <p className="text-blue-100 text-sm">24/7 disponível</p>
              </div>
            </div>
            
            <div className="flex items-center text-white justify-center">
              <Users className="h-6 w-6 mr-4 text-blue-100" />
              <div>
                <h3 className="font-semibold">Família</h3>
                <p className="text-blue-100 text-sm">Múltiplos perfis</p>
              </div>
            </div>
          </div>

          {/* Illustration */}
          <div className="flex justify-center">
            <img src="/assets/telemedicina.png" alt="Ilustração de Telemedicina" className="w-full max-w-sm h-auto rounded-lg" />
          </div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          {/* Mobile Header */}
          <div className="lg:hidden text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <Heart className="h-8 w-8 text-blue-600 mr-2" />
              <span className="text-2xl font-bold text-gray-900">OSZO</span>
            </div>
          </div>

          <Card className="border-0 shadow-xl">
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-2xl">Acesse sua conta</CardTitle>
              <CardDescription>
                Entre com suas credenciais ou crie uma nova conta
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* User Type Tabs */}
              <Tabs defaultValue="paciente" className="w-full mb-6">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="paciente">Paciente</TabsTrigger>
                  <TabsTrigger value="admin">Administrador</TabsTrigger>
                  <TabsTrigger value="cadastro">Criar Conta</TabsTrigger>
                </TabsList>
                
                <TabsContent value="paciente" className="mt-6">
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="identifier">Email ou CPF</Label>
                      <Input
                        id="identifier"
                        type="text"
                        placeholder="Digite seu email ou CPF"
                        value={loginData.identifier}
                        onChange={(e) => setLoginData({...loginData, identifier: e.target.value})}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="password">Senha</Label>
                      <div className="relative">
                        <Input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          placeholder="Digite sua senha"
                          value={loginData.password}
                          onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                          required
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? (
                            <EyeOff className="h-4 w-4" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>

                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={loading}>
                      {loading ? 'Entrando...' : 'Entrar'}
                    </Button>

                    <div className="text-center">
                      <Button variant="link" className="text-sm text-red-600">
                        Esqueceu sua senha?
                      </Button>
                    </div>

                    <div className="relative">
                      <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t" />
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-white px-2 text-gray-500">OU ENTRE COM SMS</span>
                      </div>
                    </div>

                    <Button 
                      type="button" 
                      variant="outline" 
                      className="w-full"
                      onClick={() => setLoginType('sms')}
                    >
                      Receber código por SMS
                    </Button>
                  </form>
                </TabsContent>
                
                <TabsContent value="admin" className="mt-6">
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="adminEmail">Email Administrativo</Label>
                      <Input
                        id="adminEmail"
                        type="email"
                        placeholder="Digite seu email administrativo"
                        value={loginData.identifier}
                        onChange={(e) => setLoginData({...loginData, identifier: e.target.value})}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="adminPassword">Senha</Label>
                      <Input
                        id="adminPassword"
                        type="password"
                        placeholder="Digite sua senha"
                        value={loginData.password}
                        onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                        required
                      />
                    </div>

                    <Button type="submit" className="w-full bg-gray-800 hover:bg-gray-900" disabled={loading}>
                      {loading ? 'Entrando...' : 'Entrar como Admin'}
                    </Button>
                  </form>
                </TabsContent>
                
                <TabsContent value="cadastro" className="mt-6">
                  <form onSubmit={handleRegister} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nome Completo</Label>
                      <Input
                        id="name"
                        type="text"
                        placeholder="Digite seu nome completo"
                        value={registerData.name}
                        onChange={(e) => setRegisterData({...registerData, name: e.target.value})}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Digite seu email"
                        value={registerData.email}
                        onChange={(e) => setRegisterData({...registerData, email: e.target.value})}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="cpf">CPF</Label>
                      <Input
                        id="cpf"
                        type="text"
                        placeholder="000.000.000-00"
                        value={registerData.cpf}
                        onChange={(e) => setRegisterData({...registerData, cpf: formatCPF(e.target.value)})}
                        maxLength={14}
                        required
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="registerPassword">Senha</Label>
                      <Input
                        id="registerPassword"
                        type="password"
                        placeholder="Digite sua senha"
                        value={registerData.password}
                        onChange={(e) => setRegisterData({...registerData, password: e.target.value})}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirmar Senha</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        placeholder="Confirme sua senha"
                        value={registerData.confirmPassword}
                        onChange={(e) => setRegisterData({...registerData, confirmPassword: e.target.value})}
                        required
                      />
                    </div>

                    <Button type="submit" className="w-full bg-orange-600 hover:bg-orange-700" disabled={loading}>
                      {loading ? 'Criando conta...' : 'Criar Conta'}
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <div className="text-center mt-6 text-sm text-gray-600">
            <p>Para teste, use:</p>
            <p><strong>Email:</strong> joao@email.com</p>
            <p><strong>Senha:</strong> 2o02!aKPmS&#123;N</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Login

