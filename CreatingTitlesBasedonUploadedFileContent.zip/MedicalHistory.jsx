import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useUser } from '../contexts/UserContext'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  FileText, 
  Download, 
  Eye, 
  Upload, 
  Search,
  Filter,
  Calendar,
  Heart,
  User,
  LogOut,
  ArrowLeft,
  Activity,
  Pill,
  ClipboardList
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

const MedicalHistory = () => {
  const navigate = useNavigate()
  const { user, logout } = useUser()
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedType, setSelectedType] = useState('all')
  const [selectedPeriod, setSelectedPeriod] = useState('all')

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  // Dados mockados de documentos médicos
  const documentos = [
    {
      id: 1,
      title: 'Exame de Sangue - Hemograma Completo',
      type: 'exame',
      medico: 'Dr. Carlos Oliveira',
      data: '2024-08-25',
      descricao: 'Exame de rotina para check-up geral',
      status: 'disponível'
    },
    {
      id: 2,
      title: 'Receita Médica - Medicamentos para Pressão',
      type: 'receita',
      medico: 'Dr. Carlos Oliveira',
      data: '2024-08-30',
      descricao: 'Prescrição de medicamentos para controle da pressão arterial',
      status: 'disponível'
    },
    {
      id: 3,
      title: 'Relatório de Consulta Cardiológica',
      type: 'relatório',
      medico: 'Dr. Carlos Oliveira',
      data: '2024-09-05',
      descricao: 'Relatório detalhado da consulta cardiológica',
      status: 'disponível'
    },
    {
      id: 4,
      title: 'Exame de Eletrocardiograma',
      type: 'exame',
      medico: 'Dr. Carlos Oliveira',
      data: '2024-09-10',
      descricao: 'ECG para avaliação da atividade cardíaca',
      status: 'processando'
    },
    {
      id: 5,
      title: 'Exame Dermatológico - Biópsia',
      type: 'exame',
      medico: 'Dra. Ana Costa',
      data: '2024-07-15',
      descricao: 'Resultado da biópsia de lesão cutânea',
      status: 'disponível'
    }
  ]

  const getTypeIcon = (type) => {
    switch (type) {
      case 'exame':
        return <Activity className="h-4 w-4" />
      case 'receita':
        return <Pill className="h-4 w-4" />
      case 'relatório':
        return <ClipboardList className="h-4 w-4" />
      default:
        return <FileText className="h-4 w-4" />
    }
  }

  const getTypeColor = (type) => {
    switch (type) {
      case 'exame':
        return 'bg-blue-100 text-blue-800'
      case 'receita':
        return 'bg-green-100 text-green-800'
      case 'relatório':
        return 'bg-purple-100 text-purple-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'disponível':
        return 'bg-green-100 text-green-800'
      case 'processando':
        return 'bg-yellow-100 text-yellow-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const filteredDocuments = documentos.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doc.medico.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = selectedType === 'all' || doc.type === selectedType
    
    let matchesPeriod = true
    if (selectedPeriod !== 'all') {
      const docDate = new Date(doc.data)
      const now = new Date()
      const diffTime = Math.abs(now - docDate)
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      
      switch (selectedPeriod) {
        case '30':
          matchesPeriod = diffDays <= 30
          break
        case '90':
          matchesPeriod = diffDays <= 90
          break
        case '365':
          matchesPeriod = diffDays <= 365
          break
      }
    }
    
    return matchesSearch && matchesType && matchesPeriod
  })

  const groupedDocuments = {
    exame: filteredDocuments.filter(doc => doc.type === 'exame'),
    receita: filteredDocuments.filter(doc => doc.type === 'receita'),
    relatório: filteredDocuments.filter(doc => doc.type === 'relatório')
  }

  const DocumentCard = ({ documento }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start space-x-3">
            <div className={`p-2 rounded-lg ${getTypeColor(documento.type)}`}>
              {getTypeIcon(documento.type)}
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900 mb-1">{documento.title}</h3>
              <p className="text-sm text-gray-600 mb-2">{documento.descricao}</p>
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <span>Dr. {documento.medico}</span>
                <span>•</span>
                <span>{new Date(documento.data).toLocaleDateString('pt-BR')}</span>
              </div>
            </div>
          </div>
          <Badge className={getStatusColor(documento.status)}>
            {documento.status}
          </Badge>
        </div>
        
        <div className="flex space-x-2">
          <Button size="sm" variant="outline" disabled={documento.status !== 'disponível'}>
            <Eye className="h-4 w-4 mr-2" />
            Visualizar
          </Button>
          <Button size="sm" variant="outline" disabled={documento.status !== 'disponível'}>
            <Download className="h-4 w-4 mr-2" />
            Download
          </Button>
        </div>
      </CardContent>
    </Card>
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/home')}
                className="mr-4"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
              <Heart className="h-8 w-8 text-blue-600 mr-2" />
              <span className="text-2xl font-bold text-gray-900">OSZO</span>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar} alt={user?.name} />
                    <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user?.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user?.email}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>Perfil</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Sair</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Histórico Médico</h1>
          <p className="text-gray-600">
            Acesse seus exames, receitas e relatórios médicos
          </p>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Buscar por documento ou médico..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="w-full md:w-48">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os tipos</SelectItem>
                  <SelectItem value="exame">Exames</SelectItem>
                  <SelectItem value="receita">Receitas</SelectItem>
                  <SelectItem value="relatório">Relatórios</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger className="w-full md:w-48">
                  <Calendar className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todo período</SelectItem>
                  <SelectItem value="30">Últimos 30 dias</SelectItem>
                  <SelectItem value="90">Últimos 3 meses</SelectItem>
                  <SelectItem value="365">Último ano</SelectItem>
                </SelectContent>
              </Select>

              <Button>
                <Upload className="h-4 w-4 mr-2" />
                Upload
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Documents */}
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all">
              Todos ({filteredDocuments.length})
            </TabsTrigger>
            <TabsTrigger value="exame">
              Exames ({groupedDocuments.exame.length})
            </TabsTrigger>
            <TabsTrigger value="receita">
              Receitas ({groupedDocuments.receita.length})
            </TabsTrigger>
            <TabsTrigger value="relatório">
              Relatórios ({groupedDocuments.relatório.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            {filteredDocuments.length > 0 ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredDocuments.map((documento) => (
                  <DocumentCard key={documento.id} documento={documento} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Nenhum documento encontrado
                  </h3>
                  <p className="text-gray-600">
                    Tente ajustar os filtros ou fazer uma nova busca
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="exame" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {groupedDocuments.exame.map((documento) => (
                <DocumentCard key={documento.id} documento={documento} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="receita" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {groupedDocuments.receita.map((documento) => (
                <DocumentCard key={documento.id} documento={documento} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="relatório" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {groupedDocuments.relatório.map((documento) => (
                <DocumentCard key={documento.id} documento={documento} />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default MedicalHistory

