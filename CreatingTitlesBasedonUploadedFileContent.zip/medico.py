from flask import Blueprint, jsonify, request
from src.models.medico import Medico, HorarioDisponivel, db
from datetime import datetime, date, time

medico_bp = Blueprint('medico', __name__)

@medico_bp.route('/medicos', methods=['GET'])
def get_medicos():
    specialty = request.args.get('specialty')
    if specialty:
        medicos = Medico.query.filter_by(specialty=specialty).all()
    else:
        medicos = Medico.query.all()
    return jsonify([medico.to_dict() for medico in medicos])

@medico_bp.route('/medicos', methods=['POST'])
def create_medico():
    data = request.json
    medico = Medico(
        name=data['name'],
        specialty=data['specialty'],
        rating=data.get('rating', 0.0),
        price=data['price'],
        image=data.get('image'),
        crm=data['crm']
    )
    db.session.add(medico)
    db.session.commit()
    return jsonify(medico.to_dict()), 201

@medico_bp.route('/medicos/<int:medico_id>', methods=['GET'])
def get_medico(medico_id):
    medico = Medico.query.get_or_404(medico_id)
    return jsonify(medico.to_dict())

@medico_bp.route('/medicos/<int:medico_id>/horarios', methods=['GET'])
def get_horarios_medico(medico_id):
    data_str = request.args.get('data')
    if data_str:
        data_consulta = datetime.strptime(data_str, '%Y-%m-%d').date()
        horarios = HorarioDisponivel.query.filter_by(
            medico_id=medico_id, 
            data=data_consulta,
            disponivel=True
        ).all()
    else:
        horarios = HorarioDisponivel.query.filter_by(
            medico_id=medico_id,
            disponivel=True
        ).all()
    return jsonify([horario.to_dict() for horario in horarios])

@medico_bp.route('/especialidades', methods=['GET'])
def get_especialidades():
    especialidades = [
        "Cardiologia", "Dermatologia", "Ginecologia", 
        "Neurologia", "Ortopedia", "Pediatria", 
        "Psiquiatria", "Oftalmologia"
    ]
    return jsonify(especialidades)

