from flask import Blueprint, jsonify, request
from src.models.documento_medico import DocumentoMedico, db
from datetime import datetime

documento_bp = Blueprint('documento', __name__)

@documento_bp.route('/documentos', methods=['GET'])
def get_documentos():
    paciente_id = request.args.get('paciente_id')
    tipo = request.args.get('type')
    
    query = DocumentoMedico.query
    if paciente_id:
        query = query.filter_by(paciente_id=paciente_id)
    if tipo:
        query = query.filter_by(type=tipo)
    
    documentos = query.order_by(DocumentoMedico.data_documento.desc()).all()
    return jsonify([doc.to_dict() for doc in documentos])

@documento_bp.route('/documentos', methods=['POST'])
def create_documento():
    data = request.json
    
    # Converter string para objeto date
    data_documento = datetime.strptime(data['data_documento'], '%Y-%m-%d').date()
    
    documento = DocumentoMedico(
        title=data['title'],
        type=data['type'],
        paciente_id=data['paciente_id'],
        medico_nome=data['medico_nome'],
        consulta_id=data.get('consulta_id'),
        file_path=data.get('file_path'),
        file_url=data.get('file_url'),
        descricao=data.get('descricao'),
        data_documento=data_documento
    )
    
    db.session.add(documento)
    db.session.commit()
    return jsonify(documento.to_dict()), 201

@documento_bp.route('/documentos/<int:documento_id>', methods=['GET'])
def get_documento(documento_id):
    documento = DocumentoMedico.query.get_or_404(documento_id)
    return jsonify(documento.to_dict())

@documento_bp.route('/documentos/<int:documento_id>', methods=['PUT'])
def update_documento(documento_id):
    documento = DocumentoMedico.query.get_or_404(documento_id)
    data = request.json
    
    documento.title = data.get('title', documento.title)
    documento.type = data.get('type', documento.type)
    documento.descricao = data.get('descricao', documento.descricao)
    documento.file_path = data.get('file_path', documento.file_path)
    documento.file_url = data.get('file_url', documento.file_url)
    
    db.session.commit()
    return jsonify(documento.to_dict())

@documento_bp.route('/documentos/<int:documento_id>', methods=['DELETE'])
def delete_documento(documento_id):
    documento = DocumentoMedico.query.get_or_404(documento_id)
    db.session.delete(documento)
    db.session.commit()
    return '', 204

