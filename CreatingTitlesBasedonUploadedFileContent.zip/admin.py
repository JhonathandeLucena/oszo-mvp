from flask import Blueprint, jsonify, request
from src.models.user import User, db
from src.models.medico import Medico
from src.models.consulta import Consulta
from src.models.documento_medico import DocumentoMedico
from datetime import datetime, timedelta

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/admin/dashboard', methods=['GET'])
def get_dashboard_stats():
    """Retorna estatísticas para o dashboard administrativo"""
    
    # Total de pacientes
    total_pacientes = User.query.filter_by(user_type='paciente').count()
    
    # Profissionais ativos
    profissionais_ativos = Medico.query.count()
    
    # Consultas agendadas
    consultas_agendadas = Consulta.query.count()
    
    # Laudos gerados
    laudos_gerados = DocumentoMedico.query.count()
    
    # Calcular variações (simuladas para demonstração)
    stats = {
        'total_pacientes': {
            'value': total_pacientes,
            'variation': '+12% vs mês anterior'
        },
        'profissionais_ativos': {
            'value': profissionais_ativos,
            'variation': '+3% vs mês anterior'
        },
        'consultas_agendadas': {
            'value': consultas_agendadas,
            'variation': '+25% vs mês anterior'
        },
        'laudos_gerados': {
            'value': laudos_gerados,
            'variation': '+8% vs mês anterior'
        }
    }
    
    return jsonify(stats)

@admin_bp.route('/admin/recent-activities', methods=['GET'])
def get_recent_activities():
    """Retorna atividades recentes do sistema"""
    
    # Simulando atividades recentes
    activities = [
        {
            'id': 1,
            'type': 'consulta',
            'title': 'Nova consulta agendada',
            'description': 'Maria Santos - Dr. Roberto Cardoso',
            'time': 'Há 5 min',
            'status': 'recent'
        },
        {
            'id': 2,
            'type': 'paciente',
            'title': 'Novo paciente cadastrado',
            'description': 'Carlos Eduardo Costa',
            'time': 'Há 2 horas',
            'status': 'success'
        },
        {
            'id': 3,
            'type': 'laudo',
            'title': 'Laudo médico gerado',
            'description': 'Exame cardiológico - Maria Santos',
            'time': 'Há 4 horas',
            'status': 'completed'
        }
    ]
    
    return jsonify(activities)

@admin_bp.route('/admin/patients', methods=['GET'])
def get_patients():
    """Retorna lista de pacientes"""
    patients = User.query.filter_by(user_type='paciente').all()
    return jsonify([patient.to_dict() for patient in patients])

@admin_bp.route('/admin/professionals', methods=['GET'])
def get_professionals():
    """Retorna lista de profissionais"""
    professionals = Medico.query.all()
    return jsonify([{
        'id': prof.id,
        'nome': prof.nome,
        'especialidade': prof.especialidade,
        'crm': prof.crm,
        'telefone': prof.telefone,
        'email': prof.email
    } for prof in professionals])

@admin_bp.route('/admin/consultations', methods=['GET'])
def get_consultations():
    """Retorna lista de consultas"""
    consultations = Consulta.query.all()
    return jsonify([{
        'id': cons.id,
        'paciente_id': cons.paciente_id,
        'medico_id': cons.medico_id,
        'data_consulta': cons.data_consulta.isoformat() if cons.data_consulta else None,
        'tipo': cons.tipo,
        'status': cons.status,
        'observacoes': cons.observacoes
    } for cons in consultations])

@admin_bp.route('/admin/reports', methods=['GET'])
def get_reports():
    """Retorna lista de relatórios/laudos"""
    reports = DocumentoMedico.query.all()
    return jsonify([{
        'id': doc.id,
        'paciente_id': doc.paciente_id,
        'medico_id': doc.medico_id,
        'tipo_documento': doc.tipo_documento,
        'titulo': doc.titulo,
        'data_criacao': doc.data_criacao.isoformat() if doc.data_criacao else None
    } for doc in reports])

