from flask import Blueprint, jsonify, request
from src.models.consulta import Consulta, db
from src.models.medico import HorarioDisponivel
from datetime import datetime

consulta_bp = Blueprint('consulta', __name__)

@consulta_bp.route('/consultas', methods=['GET'])
def get_consultas():
    paciente_id = request.args.get('paciente_id')
    status = request.args.get('status')
    
    query = Consulta.query
    if paciente_id:
        query = query.filter_by(paciente_id=paciente_id)
    if status:
        query = query.filter_by(status=status)
    
    consultas = query.order_by(Consulta.data.desc(), Consulta.hora.desc()).all()
    return jsonify([consulta.to_dict() for consulta in consultas])

@consulta_bp.route('/consultas', methods=['POST'])
def create_consulta():
    data = request.json
    
    # Converter strings para objetos date e time
    data_consulta = datetime.strptime(data['data'], '%Y-%m-%d').date()
    hora_consulta = datetime.strptime(data['hora'], '%H:%M').time()
    
    consulta = Consulta(
        type=data['type'],
        specialty=data['specialty'],
        medico_id=data['medico_id'],
        paciente_id=data['paciente_id'],
        data=data_consulta,
        hora=hora_consulta,
        status=data.get('status', 'agendada'),
        observacoes=data.get('observacoes')
    )
    
    db.session.add(consulta)
    
    # Marcar horário como indisponível
    horario = HorarioDisponivel.query.filter_by(
        medico_id=data['medico_id'],
        data=data_consulta,
        hora_inicio=hora_consulta
    ).first()
    if horario:
        horario.disponivel = False
    
    db.session.commit()
    return jsonify(consulta.to_dict()), 201

@consulta_bp.route('/consultas/<int:consulta_id>', methods=['GET'])
def get_consulta(consulta_id):
    consulta = Consulta.query.get_or_404(consulta_id)
    return jsonify(consulta.to_dict())

@consulta_bp.route('/consultas/<int:consulta_id>', methods=['PUT'])
def update_consulta(consulta_id):
    consulta = Consulta.query.get_or_404(consulta_id)
    data = request.json
    
    consulta.status = data.get('status', consulta.status)
    consulta.observacoes = data.get('observacoes', consulta.observacoes)
    
    db.session.commit()
    return jsonify(consulta.to_dict())

@consulta_bp.route('/consultas/<int:consulta_id>', methods=['DELETE'])
def delete_consulta(consulta_id):
    consulta = Consulta.query.get_or_404(consulta_id)
    
    # Liberar horário novamente
    horario = HorarioDisponivel.query.filter_by(
        medico_id=consulta.medico_id,
        data=consulta.data,
        hora_inicio=consulta.hora
    ).first()
    if horario:
        horario.disponivel = True
    
    db.session.delete(consulta)
    db.session.commit()
    return '', 204

