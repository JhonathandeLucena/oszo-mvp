import { useNavigate } from 'react-router-dom'
import { useUser } from '../contexts/UserContext'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { 
  Calendar, 
  FileText, 
  Bell, 
  HelpCircle, 
  Video, 
  Clock, 
  User,
  LogOut,
  Heart,
  Activity,
  Users,
  Plus,
  ArrowRight,
  CheckCircle,
  AlertCircle,
  FileCheck,
  Stethoscope,
  UserCheck,
  Droplets
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

const Home = () => {
  const navigate = useNavigate()
  const { user, logout } = useUser()

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  // Dados das estatísticas principais
  const mainStats = [
    {
      title: 'Consultas realizadas',
      value: '12',
      icon: Stethoscope,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Próximas consultas',
      value: '2',
      icon: Clock,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Exames pendentes',
      value: '1',
      icon: FileCheck,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    }
  ]

  // Ações rápidas
  const quickActions = [
    {
      title: 'Agendar Consulta',
      description: 'Presencial ou telemedicina',
      icon: Calendar,
      color: 'bg-blue-500',
      path: '/scheduling'
    },
    {
      title: 'Histórico Médico',
      description: 'Exames e relatórios',
      icon: FileText,
      color: 'bg-green-500',
      path: '/medical-history'
    },
    {
      title: 'Notificações',
      description: 'Lembretes importantes',
      icon: Bell,
      color: 'bg-orange-500',
      path: '/notifications'
    },
    {
      title: 'Suporte',
      description: 'Ajuda e acessibilidade',
      icon: HelpCircle,
      color: 'bg-blue-500',
      path: '/support'
    }
  ]

  // Próximas consultas
  const proximasConsultas = [
    {
      id: 1,
      medico: 'Dr. Maria Silva',
      especialidade: 'Cardiologia',
      data: 'Hoje, 14:30',
      tipo: 'Presencial',
      status: 'Confirmada',
      statusColor: 'bg-green-100 text-green-800'
    },
    {
      id: 2,
      medico: 'Dr. João Santos',
      especialidade: 'Clínica Geral',
      data: 'Amanhã, 16:00',
      tipo: 'Telemedicina',
      status: 'Confirmada',
      statusColor: 'bg-green-100 text-green-800'
    }
  ]

  // Perfis da família
  const perfisFamilia = [
    {
      id: 1,
      nome: 'João Silva',
      tipo: 'Titular',
      iniciais: 'JS',
      ativo: true
    },
    {
      id: 2,
      nome: 'Maria Silva',
      tipo: 'Cônjuge',
      iniciais: 'MS',
      ativo: false
    },
    {
      id: 3,
      nome: 'Ana Silva',
      tipo: 'Filha',
      iniciais: 'AS',
      ativo: false
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 to-blue-600">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-white mr-2" />
              <div>
                <span className="text-xl font-bold">OSZO</span>
                <p className="text-sm text-blue-100">Digital Health</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Bell className="h-6 w-6 text-white cursor-pointer" />
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                    <div className="h-8 w-8 rounded-full bg-white text-blue-600 flex items-center justify-center font-semibold">
                      JS
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user?.name}</p>
                      <p className="text-xs leading-none text-muted-foreground">
                        {user?.email}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <User className="mr-2 h-4 w-4" />
                    <span>Perfil</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Sair</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
          
          {/* Welcome Message */}
          <div className="pb-6 text-center sm:text-left">
            <h1 className="text-2xl font-bold text-white mb-1">
              Olá, João Silva!
            </h1>
            <p className="text-blue-100">
              Como podemos ajudá-lo hoje?
            </p>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {mainStats.map((stat, index) => (
            <Card key={index} className="bg-white shadow-lg">
              <CardContent className="flex items-center justify-center p-6">
                <div className={`p-3 rounded-lg ${stat.bgColor} mr-4`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.title}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          {/* Ações Rápidas */}
          <div className="xl:col-span-2">
            <div className="flex items-center justify-center mb-6">
              <h2 className="text-xl font-semibold text-white">Ações Rápidas</h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {quickActions.map((action, index) => (
                <Card 
                  key={index} 
                  className="cursor-pointer hover:shadow-lg transition-shadow bg-white shadow-md"
                  onClick={() => navigate(action.path)}
                >
                  <CardContent className="p-6 text-center">
                    <div className="flex flex-col items-center mb-4">
                      <div className={`p-3 rounded-lg ${action.color} mb-3`}>
                        <action.icon className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-1">{action.title}</h3>
                        <p className="text-sm text-gray-600">{action.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-center text-blue-600 text-sm font-medium">
                      <span>Acessar</span>
                      <ArrowRight className="h-4 w-4 ml-1" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Próximas Consultas */}
          <div className="xl:col-span-1">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-white">Próximas Consultas</h2>
              <Button 
                size="sm" 
                variant="outline" 
                className="bg-white text-blue-600 border-white hover:bg-blue-50 text-xs"
                onClick={() => navigate('/scheduling')}
              >
                <Plus className="h-3 w-3 mr-1" />
                Nova
              </Button>
            </div>
            <div className="space-y-3">
              {proximasConsultas.map((consulta) => (
                <Card key={consulta.id} className="bg-white shadow-md">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                          <Stethoscope className="h-4 w-4 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900 text-sm">{consulta.medico}</h3>
                          <p className="text-xs text-gray-600">{consulta.especialidade}</p>
                        </div>
                      </div>
                      <Button size="sm" variant="outline" className="text-xs">
                        Detalhes
                      </Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-gray-600">{consulta.data}</p>
                      <div className="flex items-center space-x-1">
                        <Badge className={`${consulta.statusColor} text-xs`}>
                          {consulta.status}
                        </Badge>
                        {consulta.tipo === 'Telemedicina' && (
                          <Button size="sm" className="bg-blue-500 hover:bg-blue-600 text-xs">
                            <Video className="h-3 w-3 mr-1" />
                            Iniciar
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar - Perfis da Família e Dicas */}
          <div className="xl:col-span-1 space-y-6">
            {/* Perfis da Família */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-white">Perfis da Família</h2>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="bg-white text-blue-600 border-white hover:bg-blue-50 text-xs"
                >
                  <Plus className="h-3 w-3 mr-1" />
                  Adicionar
                </Button>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {perfisFamilia.map((perfil) => (
                  <Card 
                    key={perfil.id} 
                    className={`cursor-pointer transition-all shadow-md ${
                      perfil.ativo 
                        ? 'bg-white ring-2 ring-blue-500' 
                        : 'bg-white hover:bg-gray-50'
                    }`}
                  >
                    <CardContent className="p-3 text-center">
                      <div className={`h-10 w-10 rounded-full mx-auto mb-2 flex items-center justify-center font-semibold text-sm ${
                        perfil.ativo 
                          ? 'bg-blue-500 text-white' 
                          : 'bg-gray-200 text-gray-600'
                      }`}>
                        {perfil.iniciais}
                      </div>
                      <p className="text-xs font-medium text-gray-900">{perfil.nome.split(' ')[0]}</p>
                      <p className="text-xs text-gray-600">{perfil.tipo}</p>
                      {perfil.ativo && (
                        <Badge className="mt-1 bg-green-100 text-green-800 text-xs">
                          Ativo
                        </Badge>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Dicas de Saúde */}
            <Card className="bg-white shadow-md">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center">
                  <Droplets className="h-4 w-4 text-green-600 mr-2" />
                  Dicas de Saúde
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                    <div>
                      <h4 className="font-medium text-gray-900 text-sm">Hidratação é fundamental</h4>
                      <p className="text-xs text-gray-600 mt-1">
                        Beba pelo menos 2 litros de água por dia para manter seu corpo hidratado e saudável.
                      </p>
                      <Button variant="link" className="p-0 h-auto text-blue-600 text-xs mt-2">
                        Ler mais dicas →
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home

