import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useUser } from '../contexts/UserContext'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  CheckCircle, 
  Calendar, 
  Clock, 
  User as UserIcon, 
  MapPin, 
  Video,
  Edit,
  Heart,
  LogOut
} from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'

const Confirmation = () => {
  const navigate = useNavigate()
  const { user, logout } = useUser()
  const [consultaData, setConsultaData] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    // Recuperar dados do agendamento do localStorage
    const savedConsulta = localStorage.getItem('consultaAgendamento')
    if (savedConsulta) {
      try {
        const data = JSON.parse(savedConsulta)
        setConsultaData(data)
      } catch (error) {
        console.error('Erro ao carregar dados da consulta:', error)
        navigate('/scheduling')
      }
    } else {
      navigate('/scheduling')
    }
  }, [navigate])

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  const handleConfirm = async () => {
    setLoading(true)
    
    try {
      // Simular confirmação da consulta
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      // Limpar dados do localStorage
      localStorage.removeItem('consultaAgendamento')
      
      toast.success('Consulta confirmada com sucesso!')
      navigate('/home')
    } catch (error) {
      toast.error('Erro ao confirmar consulta')
    } finally {
      setLoading(false)
    }
  }

  const handleEdit = () => {
    navigate('/scheduling')
  }

  const handleCancel = () => {
    localStorage.removeItem('consultaAgendamento')
    navigate('/home')
  }

  if (!consultaData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Heart className="h-8 w-8 text-blue-600 mr-2" />
              <span className="text-2xl font-bold text-gray-900">OSZO</span>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar} alt={user?.name} />
                    <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user?.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user?.email}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <UserIcon className="mr-2 h-4 w-4" />
                  <span>Perfil</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Sair</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Success Icon */}
        <div className="text-center mb-8">
          <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Quase pronto!</h1>
          <p className="text-gray-600">Revise os detalhes da sua consulta antes de confirmar</p>
        </div>

        {/* Consultation Summary */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Resumo da Consulta
            </CardTitle>
            <CardDescription>
              Verifique se todas as informações estão corretas
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Tipo de Consulta */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                {consultaData.type === 'online' ? (
                  <Video className="h-5 w-5 text-blue-600 mr-3" />
                ) : (
                  <MapPin className="h-5 w-5 text-green-600 mr-3" />
                )}
                <div>
                  <p className="font-medium">Tipo de Consulta</p>
                  <p className="text-sm text-gray-600">
                    {consultaData.type === 'online' ? 'Teleconsulta' : 'Presencial'}
                  </p>
                </div>
              </div>
              <Badge variant={consultaData.type === 'online' ? 'default' : 'secondary'}>
                {consultaData.type === 'online' ? 'Online' : 'Presencial'}
              </Badge>
            </div>

            {/* Médico */}
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <Avatar className="h-12 w-12 mr-4">
                  <AvatarImage src={consultaData.doctor?.image} alt={consultaData.doctor?.name} />
                  <AvatarFallback>{consultaData.doctor?.name?.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{consultaData.doctor?.name}</p>
                  <p className="text-sm text-gray-600">{consultaData.specialty}</p>
                  <p className="text-sm text-gray-500">{consultaData.doctor?.crm}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-blue-600">
                  R$ {consultaData.doctor?.price?.toFixed(2)}
                </p>
              </div>
            </div>

            {/* Data e Horário */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center p-4 bg-gray-50 rounded-lg">
                <Calendar className="h-5 w-5 text-blue-600 mr-3" />
                <div>
                  <p className="font-medium">Data</p>
                  <p className="text-sm text-gray-600">
                    {consultaData.date?.toLocaleDateString('pt-BR', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>
              </div>

              <div className="flex items-center p-4 bg-gray-50 rounded-lg">
                <Clock className="h-5 w-5 text-blue-600 mr-3" />
                <div>
                  <p className="font-medium">Horário</p>
                  <p className="text-sm text-gray-600">{consultaData.time}</p>
                </div>
              </div>
            </div>

            {/* Paciente */}
            <div className="flex items-center p-4 bg-gray-50 rounded-lg">
              <Avatar className="h-12 w-12 mr-4">
                <AvatarImage src={user?.avatar} alt={user?.name} />
                <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{user?.name}</p>
                <p className="text-sm text-gray-600">{user?.email}</p>
                <p className="text-sm text-gray-500">{user?.cpf}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Important Information */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Informações Importantes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm text-gray-600">
              {consultaData.type === 'online' ? (
                <>
                  <p>• Você receberá um link para a videochamada por email 30 minutos antes da consulta</p>
                  <p>• Certifique-se de ter uma conexão estável com a internet</p>
                  <p>• Teste sua câmera e microfone antes da consulta</p>
                  <p>• Tenha seus documentos médicos em mãos</p>
                </>
              ) : (
                <>
                  <p>• Chegue com 15 minutos de antecedência</p>
                  <p>• Traga um documento de identidade com foto</p>
                  <p>• Leve seus exames e documentos médicos</p>
                  <p>• Em caso de atraso, entre em contato conosco</p>
                </>
              )}
              <p>• O cancelamento deve ser feito com pelo menos 24 horas de antecedência</p>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button variant="outline" onClick={handleCancel}>
            Cancelar
          </Button>
          <Button variant="outline" onClick={handleEdit}>
            <Edit className="h-4 w-4 mr-2" />
            Editar
          </Button>
          <Button 
            onClick={handleConfirm} 
            disabled={loading}
            className="px-8"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Confirmando...
              </>
            ) : (
              <>
                <CheckCircle className="h-4 w-4 mr-2" />
                Confirmar Consulta
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}

export default Confirmation

